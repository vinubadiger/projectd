import React from 'react';
import { Menu, Icon, Button } from 'antd';
import { BrowserRouter as Router, Route, Link, Switch } from 'react-router-dom';
import './sidebar.less';

const urls = require('./../../utility/urls').default;
const SubMenu = Menu.SubMenu;
const MenuItemGroup = Menu.ItemGroup;
class NavigationBar extends React.Component {
  rootSubmenuKeys = ["sub1", "sub2", "sub3"];

  constructor(props) {
    super(props);
    this.state = {
      openKeys: '',
      projects: [],
      source_list: [],
      recon_list: [],
      
    };


  }
  
 
  handleClick = (e) => {
    var productname = e.key;
    console.log('data ', productname);
    //results for source and recon jobs with respective to project
    fetch("http://10.11.14.79/recon/product/get/" + productname)
      .then(res => res.json())
      .then(
        (result) => {
          this.setState({ source_list: result.sourceList })
          this.setState({ recon_list: result.reconList })
        },

        (error) => {
          console.log("Cannot fetch source list");
          console.log(error);
        }
      )
  }

  //Fetch All projects
  componentDidMount() {

    fetch("http://10.11.14.79/recon/product/getlist")


      .then(res => res.json())
      .then(
        (result) => {
          console.log("Result::", result)

          this.setState({
            projects: result
          });
        },

        (error) => {
          console.log("Cannot fetch product list");
          console.log(error);
        }
      )

  }

  render() {
    
    console.log("IN SIDEBAR::",this.props.param)
    return (

      <Menu theme="dark" mode="inline" inlineIndent="20">
        <Menu.Item className="customHome" key="1">
          <Link to="/welcome">
            <Icon type="home" />
            <span >Home</span>
          </Link>
        </Menu.Item>


        <Menu.Item className="customSubMenuTitleColor customNewProject" key="2">


          <span >New Projects </span>
          <Icon type="plus-circle-o" />
        </Menu.Item>

        <SubMenu className="customSubMenuTitleColor customSelectedProject" hoverable="false" key={this.props.param} title={<span>{this.props.param}</span>} onTitleClick={this.handleClick}>
          <SubMenu className="customSubMenuTitleColor customSProjectSources " hoverable="false" key="1" title={<span>Source</span>}  >

            {
              this.state.source_list.map(sourceJobs =>
                <Menu.Item className="customSProjectSourcesSubmenu" key={sourceJobs.name}>{sourceJobs.name} </Menu.Item>

              )
            }
            <Menu.Item className=" customSProjectSourcesSubmenu" key="3">


              <span >New Source </span>
              <Icon type="plus-circle-o" />
            </Menu.Item>
          </SubMenu>
          <SubMenu size="small" className="customSubMenuTitleColor customSProjectSourcesSubmenu" hoverable="false" key="2" title={<span>Recon</span>} onTitleClick={this.handleClick} >
            {
              this.state.recon_list.map(reconJobs =>
                <Menu.Item className=" customSProjectSourcesSubmenu" key={reconJobs.name}>{reconJobs.name}</Menu.Item>
              )
            }
            <Menu.Item className=" customSProjectSourcesSubmenu" key="4">


              <span >New Recon Job </span>
              <Icon type="plus-circle-o" />
            </Menu.Item>
          </SubMenu>
        </SubMenu>

      </Menu>




    );
  }
}
export default NavigationBar;



