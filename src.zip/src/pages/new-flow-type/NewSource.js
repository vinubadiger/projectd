import React, { Component } from 'react';
import { Card, Col, Row, Button, Icon, Avatar,Dropdown,Menu, Radio } from 'antd';
import { BrowserRouter as Router, Route, Link, Switch, Redirect} from 'react-router-dom';
import './NewSource.less';
import ReconForm from './../../pages/modal-forms/CreateRecon';
import ETLForm from '../modal-forms/CreateSource';
import CompactTable from './../../components/table/index';

const urls = require('./../../utility/urls.js').default;
const RadioGroup = Radio.Group;
const { Meta } = Card;
// const data = [{
//     key: '1',
//     Source: 'recType',
//     Action: <div><center>
//         <Icon className="icons" type="edit"/>

//         <Icon className="icons" type="delete"/></center>
//     </div>
// }, {
//     key: '2',
//     Source: 'FileName',
//     Action: <div><center>
//         <Icon className="icons" type="edit"/>

//         <Icon className="icons" type="delete"/></center>
//     </div>
// },
// {
//     key: '3',
//     Source: 'NewrecType',
//     Action: <div><center>
//         <Icon className="icons" type="edit"/>

//         <Icon className="icons" type="delete"/></center>
//     </div>
// }];

const columns = [{
    title: 'Name',
    dataIndex: 'Source',
    key: 'Source',
}, {
    title: <div>Action
    </div>,
    dataIndex: 'Action',
    key: 'Action',
}];


export default class newflowtype extends Component {
            
    constructor(props)
    {
        super(props);

    }
    state = { 
        visible: false,
        visibleETL: false,
        data :[],
        value: 1,
    };

    showModal = () => {
        this.setState({
            visible: true,
        });
    }

    showModal1 = () => {
        this.setState({
            visibleETL: true,
        });
    }

    handleCancel = () => {
        const form = this.formRef.props.form;
        this.setState({ visible: false });
        form.resetFields();
    }

    handleCancelETL = () => {
        const form = this.formRef.props.form;
        this.setState({ visibleETL: false });
        form.resetFields();
    }
    
    saveFormRef = (formRef) => { this.formRef = formRef; }

    getProductSources() {
        fetch(urls.urlarray.GetProductDetails)
        .then(res => res.json())
        .then(
            (result) => {
              console.log("LIST :: ",result.sources);
      
              var rows = [];
      
              for (let i = 0; i <result.sources.length ; i++){
      
                  var object = {};
                  object.Source = result.sources[i].sourceName;
                  object.Action =  <div><center>
                          <Icon className="icons" type="copy"/>
                  
                           <Icon className="icons" type="delete"/></center>
                       </div>;      
                 rows.push(object);
      
              }
      
              console.log("ROWS :: ",rows)
      
              this.setState({
                  data : rows,
              });
      
            },
      
            (error) => {
              console.log("Cannot fetch source list");
              console.log(error);
            }
          )
    }    

    getProductRecons() {
        fetch(urls.urlarray.GetProductDetails)
        .then(res => res.json())
        .then(
            (result) => {
              console.log("LIST :: ",result.recons);
      
              var rows = [];
      
              for (let i = 0; i <result.recons.length ; i++){
      
                  var object = {};
                  object.Source = result.recons[i].reconName;
                  object.Action =  <div><center>
                          <Icon className="icons" type="copy"/>
                  
                           <Icon className="icons" type="delete"/></center>
                       </div>;      
                 rows.push(object);
      
              }
      
              console.log("ROWS :: ",rows)
      
              this.setState({
                  data : rows,
              });
      
            },
      
            (error) => {
              console.log("Cannot fetch source list");
              console.log(error);
            }
          )
    }  

    onChange = (e) => {
        console.log('radio checked', e.target.value);
        this.setState({
          value: e.target.value,
        });

        if( e.target.value==1)
        {
            this.getProductSources();
        }else{
            this.getProductRecons();
        }
      }
   
     componentDidMount()
     {
        this.getProductSources();
     }

    render() {

        console.log("FLOW TYPE RENDER :: ",this.props.openProject);


       

        return (
            <div>

                <div className='contentDiv' >
                    <Row gutter={16}>
                        <Col span={7}>
                    <h3><center>Your Sources</center></h3>
                            <Button size="large" className='newButton' onClick={this.showModal1}>
                                < Icon className="addIcon" type="plus" /><br />Add Source
                            </Button>
                        </Col>
                        <Col span={7} style={{marginLeft:"7em"}}>
                        <h3><center>Your Reconciliation Jobs</center></h3>
                            <Button size="large" className='newButton' onClick={this.showModal}>
                                < Icon className="addIcon" type="plus" /><br />Add Reconciliation Job
                            </Button>
                        </Col>
                    </Row>
                </div>

            {/* <Card> */}
                <div className='contentDiv2'>
                    <Row gutter={16}>
                    <center>
                    <RadioGroup onChange={this.onChange} value={this.state.value} defaultValue={1}>
                        <Radio value={1} className="radiodata">Recent Sources</Radio>
                        <Radio value={2} className="radiodata">Recent Reconciliation Jobs</Radio>
                    </RadioGroup>
                    </center>
                    </Row>
                </div>

                <div className='contentDiv3'>
                    <Row gutter={16}>
                        <CompactTable size="small" columns={columns} dataSource={this.state.data}/>
                    </Row>
                </div>
 
                {/* </Card> */}
                <ReconForm
                wrappedComponentRef={this.saveFormRef}
                visible={this.state.visible}
                onCancel={this.handleCancel}
                proj={this.props.openProject}/>

                <ETLForm
                wrappedComponentRef={this.saveFormRef}
                visible={this.state.visibleETL}
                onCancel={this.handleCancelETL}
                proj={this.props.openProject}
                />

            </div>
        )
    }
}
