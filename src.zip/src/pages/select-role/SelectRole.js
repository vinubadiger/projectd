import React, { Component } from 'react';
import { Row, Col} from 'antd';
import OperationCenter from './../../assets/icons/Operation center.png';
import Reports from './../../assets/icons/Reports.png'
import Academy from './../../assets/icons/Academy.png'
import FlowDesign from './../../assets/icons/Flow designer.png'
import UserRoles from './../../assets/icons/User roles.png'
import CaseManagement from './../../assets/icons/Casemanagement.png'
import CustomHeader from './../../components/header/index'
import Image1 from './../../components/navbar-logo/image1';
import Dashboard from './../dashboard/DashboardLand';
import { BrowserRouter as Router, Route, Link, Switch,Redirect } from 'react-router-dom';
import './SelectRole.less';
import BackgroundImg from './../../assets/images/welcomeImg.jpg';
class SelectRole extends Component {

    render() {
        return (
            <div className="roleMainDiv">
                <div><Image1/></div>
                <CustomHeader  showBurgerMenu = {false} showIcon = {false} collapsedClick = {this.toggle}  showDrawar = {this.showDrawar} />
                <img className="welcomeBgImg" src={BackgroundImg}></img>
                <div className="welcomeBackground">
                    <div className="titleDiv">
                        <h1>Welcome to Optimus!</h1>
                    </div>
                    <div>
                        <Row>
                            <Col span={10}>
                                <img className="welcomeImg" src="https://www.opusconsulting.com/wp-content/uploads/2017/07/new-slider-element.png" />
                            </Col>
                            <Col span={8}>
                                <div className="selectRole">
                                    <div className="roleDiv">
                                        <img src={OperationCenter} alt='OperationCenter' /><br /><br />
                                        <h3>Operation Center</h3>
                                    </div>
                                    <div className="roleDiv">
                                        <img src={Reports} alt='Reports' /><br /><br />
                                        <h3>Reports</h3>
                                    </div>
                                    <div className="roleDiv">
                                        <Link to="/MainBoard">
                                                <img src={FlowDesign} alt='FlowDesign' /><br /><br />
                                                <h3>Flow Design</h3>
                                        </Link>
                                    </div>
                                </div>
                                <div className="selectRole">                 
                                    <div className="roleDiv">
                                        <img src={UserRoles} alt='User Roles' /><br /><br />
                                        <h3>User Roles</h3>
                                    </div>
                                    <div className="roleDiv">
                                        <img src={CaseManagement} alt='Case management' /><br /><br />
                                        <h3>Case management</h3>
                                    </div>
                                    <div className="roleDiv">
                                        <img src={Academy} alt='Academy' /><br /><br />
                                        <h3>Academy</h3>
                                    </div>                   
                                </div>
                            </Col>
                        </Row>
                    </div>
                </div>
            </div>
          );
    }
}
export default SelectRole;