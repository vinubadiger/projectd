export default {
    maparray: 
        {           
            "duplicate_etl_jobs": "Here you can manage and manage the datasets you added."+
                                    "A dataset holds a raw data that can be used as a raw"+
                                    " material without affecting your original data"
        ,
            "question_info" : "Information- What will happen if user chooses yes or no",

            "file_layout" : "Information about file layout"
        }

    // layoutdefinition:
    //     {
            
    //         "question_info" : "Information- What will happen if user chooses yes or no"
    //     }
    
    }