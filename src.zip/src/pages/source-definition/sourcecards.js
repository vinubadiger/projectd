import React, { Component } from 'react';
import { Card, Col, Row, Layout, Icon, Upload, message } from 'antd';
import './SourceDefinition.less'
import {Link} from 'react-router-dom';
const { Content } = Layout;
const props = {
  name: 'file',
  action: '//jsonplaceholder.typicode.com/posts/',
  headers: {
    authorization: 'authorization-text',
  },
  onChange(info) {
    if (info.file.status !== 'uploading') {
      console.log(info.file, info.fileList);
    }
    if (info.file.status === 'done') {
      message.success(`${info.file.name} file uploaded successfully`);
    } else if (info.file.status === 'error') {
      message.error(`${info.file.name} file upload failed.`);
    }
  },
};


class SourceCards extends Component {

  render() {
    return (
      <Content >
        <div className="cardsBackground">
          <tr>
            <Row gutter={16}>
            <Link to="LayoutDefinition">
              <Col span={7}>
                  <div className="iconDiv">
                    <Icon className="cardIcons" type="file-text" />
                  </div>
                  <Card className="styleCards" bordered={true}>
                    Create Configuration for CSV file Sources
                    </Card>
              </Col>
              

              <Col span={7} className="sourceCardsDiv">

               
                  <div className="iconDiv">
                    <Icon className="cardIcons" type="file-text" />
                  </div>
                  <Card className="styleCards" bordered={true}>
                    Create configuraion for excel file sources
                        </Card>
                

              </Col>
              <Col span={7} className="sourceCardsDiv">
               
                  <div className="iconDiv">
                    <Icon className="cardIcons" type="file-text" />
                  </div>
                  <Card className="styleCards" bordered={true}>Browse repo / marketplace for more
                  </Card>
            

              </Col>
             </Link>
            </Row>

          </tr>
        </div>
      </Content>

    );
  }
}

export default SourceCards;

