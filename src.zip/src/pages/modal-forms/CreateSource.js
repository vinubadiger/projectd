import React from "react";
import "antd/dist/antd.css";
import { Button, Modal, Form, Input, InputNumber, Radio, Select, Spin, Icon} from "antd";
import { BrowserRouter as Router, Route, Link, Switch, Redirect} from "react-router-dom";
import "./CreateSource.less";

const FormItem = Form.Item;
const RadioGroup = Radio.Group;
const Option = Select.Option;

const CreateETLForm = Form.create()(
  class extends React.Component {
    constructor(props) {
      super(props);
      this.state = {
        nextETL: false,
        srcname: ''
      }; 
    }

    handleCreateETL = () => {
      //  console.log("handleCreateETL", this.props.proj)
      this.saveSource();
      this.setState({ nextETL: true });
      console.log("ELE Changed to TRUE"); 
    };

    handleChange = (e) => {
      this.setState({ srcname: e.target.value });
      console.log("srcname>",this.state.srcname);
    }

    saveSource() {
      fetch("http://10.11.14.79/recon/product/saveProductSource/"+this.props.proj, {
        method: "POST",
        //  mode: 'no-cors',
        headers: {
          "Content-Type": "application/json"
          //   'Access-Control-Allow-Origin':'*'
        },
        body: JSON.stringify({
          id: "12",
          name: this.state.srcname,
        })
      })
        .then(response => {
          console.log("saved successfully", response);
          if (response.status == 200) {
            this.getProductData();
          }
        })
        .catch(err => err);
    }

    
    getProductData() {
      fetch("http://10.11.14.79/recon/product/getlist")
      .then(res => res.json())
      .then(
        (result) => {
          console.log("result111source",result.sourceList)
        },
        (error) => {
          console.log("error in get product source");
          console.log(error);
        }
      )
}

    render() {
      const { visible, onCancel, form, proj } = this.props;
      const { getFieldDecorator } = form;

      console.log("ETL FORM RENDER",proj)
      if (this.state.nextETL) {
        return <Redirect to="/ReconFlow" />;
      }

      return (
        <div>
          <Modal
            visible={visible}
            title="Source"
            okText="Next"
            onCancel={onCancel}
            onOk={this.handleCreateETL}
            className="ETLForm"
          >
            <Form>
              <FormItem label="Source Name">
                {getFieldDecorator("title", {
                  rules: [
                    { required: true, message: "Please enter Source Name!" }
                  ]
                })(<Input placeholder="Enter Source Name" onChange={this.handleChange} />)}
              </FormItem>

              <br />
              <br />
            </Form>
          </Modal>
        </div>
      );
    }
  }
);
export default CreateETLForm;
