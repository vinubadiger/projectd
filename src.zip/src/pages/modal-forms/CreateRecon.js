import React from 'react';
import 'antd/dist/antd.css';
import { BrowserRouter as Router, Route, Link, Switch, Redirect} from "react-router-dom";
import { Button, Modal, Form, Input, InputNumber, Radio, Select,Card, Spin, Icon } from 'antd';
import './CreateRecon.less'

const FormItem = Form.Item;
const RadioGroup = Radio.Group;
const Option = Select.Option;

const urls = require('./../../utility/urls.js').default;
const CreateRecon = Form.create()(
  class extends React.Component {

    constructor(props) { 
        super(props);
        this.state = {
          next:false,
      };
      this.handleChange = this.handleChange.bind(this);
    }

    handleChange = (e) => {
      this.setState({ reconname: e.target.value });
      console.log("reconname>",this.state.reconname);
    }

    handleCreate = () => {
      //  console.log("handleCreateETL", this.props.proj)
      this.saveJob();
      this.setState({ next:true });  
    };

    
    saveJob() {
      fetch(urls.urlarray.SaveReconJob/*+this.props.proj*/, {
        method: "POST",
        //  mode: 'no-cors',
        headers: {
          "Content-Type": "application/json"
          //   'Access-Control-Allow-Origin':'*'
        },
        body: JSON.stringify({
          "reconId": "12",
          "reconName": this.state.reconname,
        })
      })
        .then(response => {
          console.log("saved successfully", response);
          if (response.status == 200) {
            this.getProductData();
          }
        })
        .catch(err => err);
    }

    
    getProductData() {
      fetch("http://10.11.14.79/recon/product/getlist")
      .then(res => res.json())
      .then(
        (result) => {
          console.log("result111source",result.sourceList)
        },
        (error) => {
          console.log("error in get product source");
          console.log(error);
        }
      )
}

    render() {
      const { visible, onCancel, form, proj } = this.props;

      console.log("RECON FORM RENDER",proj)
      if(this.state.next) {
        return <Redirect to="/ReconFlow"/>
    }

      return (
        <div>
          <Modal 
            visible={visible}
            title="Reconciliation"
            okText="Next"
            onCancel={onCancel}
            onOk={this.handleCreate}
            className="verticalModal"
            >
            <Form>
              <FormItem className="formLabels" label="Profile Description">
                {(<Input  placeholder="Enter Reconciliation Job Name" onChange={this.handleChange} />)}
              </FormItem> 

              <br/>
              <br/>

              <FormItem className="formLabels" label="Number of Data Sources" style={{display: 'flex', flexDirection: 'row'}}>
                {(<InputNumber min={1} max={10} defaultValue={1}
                                value={2}                       // remove this line when non-static value to be shown
                                onChange={this.handleChange}
                                style={{marginLeft:'15px', width:"115px"}}  />)}
                {/* <Button type="primary" shape="circle" icon="check" size='medium' style={{marginLeft:'15px'}} /> */}
              </FormItem>

              <FormItem className="formLabels" label="Source A" style={{display: 'flex', marginLeft: "97px"}}>
                <Select
                  showSearch
                  placeholder="Select Source A"
                  style={{width: "230px", marginLeft: "15px"}}
                >
                  <Option value="BOA-Recon">BOA-Recon</Option>
                  <Option value="First Data">First Data</Option>
                  <Option value="Vantiv">Vantiv</Option>
                  <Option value="Chase Payment">Chase Payment</Option>
                  <Option value="Samson">Samson</Option>
                </Select>

              </FormItem>

              
              <FormItem  className="formLabels" label="Source B" style={{display: 'flex', marginLeft: "97px"}}>
                <Select
                  showSearch
                  placeholder="Select Source B"
                  style={{width: "230px", marginLeft: "15px"}}>   
                  <Option value="BOA-Recon">BOA-Recon</Option>
                  <Option value="First Data">First Data</Option>
                  <Option value="Vantiv">Vantiv</Option>
                  <Option value="Chase Payment">Chase Payment</Option>
                  <Option value="Samson">Samson</Option>
                </Select>
              </FormItem>
            </Form>
          </Modal>
        </div>
      );
    }
  }
);
export default CreateRecon;
