
import React, { Component } from 'react';
import { BrowserRouter as Router, Route, Link, Switch, Redirect } from 'react-router-dom';
import SourceDefinition from './../source-definition/SourceDefinition';
import LayoutDefinition from './../layout-definition/LayoutDefinition';
import RecordTokenizer from './../record-tokenizer/RecordTokenizer';
import Login from './../login/Login';
import NavigationBar from './../../layouts/sidebar/index';
import Preview from './../preview/preview';
import { Layout, Menu, Icon, Input, Dropdown, Select } from 'antd';
import './siderlayout.css';

import TaskDesign from './../BpmnBoard/BpmnBoard';
import TLogo from './../../components/navbar-logo-single-T/logo'
import Image from './../../components/navbar-logo/image';
import MainBoard from './../main-board/mainBoard';
import ReconFlow from '../recon-flow/ReconFlow';
import welcome from './../select-role/SelectRole';
import Dashboard from './../dashboard/DashboardLand';
import Flowtype from './../new-flow-type/NewSource';
import tablescreen from './../tablescreen/tabscreen'
import tablescreen1 from './../tablescreen/tabscreen1'
import tablescreen2 from './../tablescreen/tabscreen2'
import CustomHeader from './../../components/header/index'

const Search = Input.Search;
const Option = Select.Option;
const { Header, Sider, Content } = Layout;
const menu1 = (
    <Menu>
        <Menu.Item key="0">
            <a>You are all caught up! </a>

        </Menu.Item>
    </Menu>
);
const menu2 = (
    <Menu>
        <Menu.Item key="0">
            <a>No new messages</a>
        </Menu.Item>
    </Menu>
);
const menu3 = (
    <Menu className="menu">
        <Menu.Item key="0">
            <Icon type="profile" />
            <span><a style={{ color: '#757E82' }}>Edit Profile</a></span>
        </Menu.Item>
        <Menu.Divider className="menu9" />
        <Menu.Item key="1">
            <Icon type="read" />
            <span><a style={{ color: '#757E82' }}>View Profile</a></span>
        </Menu.Item>
        <Menu.Divider className="menu9" />
        <Menu.Item key="2">
            <Icon type="logout" />
            <span><a style={{ color: '#757E82' }}>Sign Out</a></span>
        </Menu.Item>

    </Menu>
);


export default class Routes extends Component {

    constructor(props) {
        super(props);
        this.state = {
            collapsed: false,
            projects: [],
            openProject: "Chase Payment",
            defaultval: 'Chase Payment'
        };
        this.handleChange = this.handleChange.bind(this);
    }
    handleChange(value) {
        console.log(`selectedinroutes ${value}`);

        const openArray = [];
        openArray.push(value);

        this.setState({ openProject: value });
    }

    componentDidMount() {

        fetch("http://10.11.14.79/recon/product/getlist/")
            .then(res => res.json())
            .then(
                (result) => {
                    console.log("Result::", result)
                    this.setState({
                        projects: result
                    });
                },

                (error) => {
                    console.log("Cannot fetch product list");
                    console.log(error);
                }
            )
    }

    toggle = () => {
        this.setState({
            collapsed: !this.state.collapsed,
        });
    }


    render() {

        console.log("ROUTE RENDER ::",this.state.openProject)

        const logo = this.state.collapsed;

      
        return (
            <div>
                <Router>
                    <div >
                        <Switch>
                            <Route
                                exact
                                path="/"
                                component={Login}
                            />

                            <Route
                                exact
                                path="/welcome"
                                component={welcome}
                            />
                        
                            <Layout>
                                <Sider
                                    trigger={null}
                                    collapsible
                                    collapsed={this.state.collapsed}

                                >
                                    {logo ? (
                                        <div className='sidebar'><div><Link to="/welcome"><TLogo /></Link></div><div><NavigationBar param={this.state.openProject} /></div></div>
                                    ) : (
                                            <div className='sidebar'><div><Link to="/welcome"><Image /></Link></div><div><NavigationBar param={this.state.openProject} /></div></div>)
                                    }

                                </Sider>

                                {/* <Sider
                                    trigger={null}
                                    collapsible
                                    collapsed={!this.state.collapsed} 
                                >
                                    <NavigationBar1 />
                                </Sider> */}
                                <Layout>
                                <CustomHeader handleChange = {this.handleChange} showProjects = {true} showBurgerMenu = {true} showIcon = {false} collapsedClick = {this.toggle}  showDrawar = {this.showDrawar}/>
                                    
                                    <Content style={{ margin: '24px 16px', padding: 24, background: '#fff', minHeight: 280 }}>
                                        <Route
                                            exact
                                            path="/SourceDefinition"
                                            component={SourceDefinition}
                                        />
                                        <Route
                                            exact
                                            path="/LayoutDefinition"
                                            component={LayoutDefinition}
                                        />
                                        <Route
                                            exact
                                            path="/RecordTokenizer"
                                            component={RecordTokenizer}
                                        />
                                        <Route
                                            exact
                                            path="/Preview"
                                            component={Preview}
                                        />
                                        <Route
                                            exact
                                            path="/TaskDesign"
                                            component={TaskDesign}
                                        />
                                        <Route
                                            exact
                                            path="/ReconFlow"
                                            component={ReconFlow}
                                        />
                                        <Route
                                            //exact
                                            path="/flowtype"
                                            render={(props) => (<Flowtype {...props} openProject={this.state.openProject} />)}
                                            //render={(routeProps)=><flowtype {...routeProps} openProject={this.state.openProject}/>}
                                            //component={flowtype}
                                         
                                        />
                                        <Route
                                            exact
                                            path="/tablescreen"
                                            component={tablescreen}
                                        />
                                        <Route
                                            exact
                                            path="/tablescreen1"
                                            component={tablescreen1}
                                        />
                                        <Route
                                            exact
                                            path="/tablescreen2"
                                            component={tablescreen2}
                                        />

                                         <Route
                                            exact
                                            path="/MainBoard"
                                            component={MainBoard}
                                        />
                                          
                                    </Content>
                                </Layout>
                            </Layout>

                        </Switch>
                    </div>
                </Router>
            </div>
        );
    }
}