import React, { Component } from 'react';
import { Link } from 'react-router-dom';
import { Select, Steps, Modal} from 'antd';
import Img from './../../assets/images/flowDig.png';
import './ReconFlow.less'
import AddNewRecord from './../modal-forms/AddNewRecord';
import ReconProcess1 from './../modal-forms/ReconProcess1';
import ReconProcess2 from './../modal-forms/ReconProcess2';
import TabModal from './TabModal';
const Step = Steps.Step;
const Option = Select.Option;

export default class ReconFlow extends Component {
    /* constructor(props) {
        super(props);
        this.currentTab = "";
        this.state = { visible: '', addRecordVisible:false, activeTab:"1" };
        this.handleOk = this.handleOk.bind(this);
        this.setCurrentTab = this.setCurrentTab.bind(this);
    }
    showModal = () => {
        this.setState({
            addRecordVisible: true,
        });
    }
    setCurrentTab = (val) =>{
        this.currentTab = val;
    }

    showModal1 = () => {
        this.setState({
            visible: true,
        });
    }
    handleOk = (e) => {

        console.log(":::::::::::::::::");


        const form = this.saveSourceForm;
      }
    
    handleCancel = (ref1) => {
        const ref = Modal.info();
         ref.destroy();
        // console.log("REF ::: ",ref1)
        // ref1.destroy();
    this.setState({ visible: false });
    }*/
    constructor(props) {
        super(props);
        this.currentTab = "";
        this.state = { visible: '', addRecordVisible: false, activeTab: "1" };
        this.handleOk = this.handleOk.bind(this);
    }
    setCurrentTab = (val) => {
        this.currentTab = val;
    }
    showModal = () => {
        this.setState({
            visible: true,
        });
    }
    showModal2 = () => {
        this.setState({
            visible: "three",
        });
    }
    showModal3 = () => {
        this.setState({
            addRecordVisible: true,
        });
    } 
    handleOk = (e) => {
        this.setState({
            visible: "two",
        });
    }
    handleCancel = () => {
        this.setState({ visible: false });
    }
    handleModal = (e) => {
        this.setState({
            visible: false,
        });
    }
    handleSave = () => {
        const form = this.saveSourceForm;
        this.setState({ visible: false });
    }
    handleCreate = () => {
        const form = this.formRef.props.form;

        form.validateFields((err, values) => {
            if (err) {
                return;
            }
            console.log('Received values of form: ', values);
            this.setState({ visible: false });
            this.setState({ loadervisible: true });
            // this.setVal(values);
            form.resetFields();
            this.setState({ sourcedef: true });

            this.setState({ loadervisible: false });

        });
    }
    saveFormRef = (formRef) => {
        console.log("saveFormRef ::: ")
        this.formRef = formRef;
    }
    handleAddRecordCancel = () => {
        console.log("handleAddRecordCancel ::: ")
        this.setState({ addRecordVisible: false });
    }
    render(){        
        const modalview = this.state.visible;
        console.log("RECON FLOW RENDER :: ",modalview);
        return(
            <div>
                <img className='taskDesign' src={Img} />

                <div className="clickableDiv" onDoubleClick={this.showModal}></div>
                <div className="clickableDiv1" onDoubleClick={this.showModal2}></div>
                
                {(modalview === "three") ? (
                    <div>
                        <TabModal
                            setForm={this.saveSourceForm}
                            activeTab={this.state.activeTab}
                            setCurrentTab={this.setCurrentTab}
                            onClick={this.showModal3}
                            visible={this.state.visible}
                            onOk={this.handleSave}
                            onCancel={this.handleCancel} />

                        <AddNewRecord
                            wrappedComponentRef={this.saveFormRef} 
                            visible={this.state.addRecordVisible}
                            onCancel={this.handleAddRecordCancel}
                            onCreate={this.handleCreate}
                            visible1={this.state.loadervisible} />
                    </div>
                ): !(modalview === "two") ? (
                    <div>
                        <ReconProcess1
                            visible={this.state.visible}
                            onOk={this.handleOk}
                            onCancel={this.handleCancel} />
                    </div>
                ) : (<div>
                    <ReconProcess2
                        visible={this.state.visible}
                        onCancel={this.handleCancel}
                        onOk={this.handleModal} />
                </div>)}
            </div>
        )
    }
}