import React, { Component } from 'react';
import { Layout, Menu, Icon, Input, Dropdown,Select } from 'antd';
import Image from '../../components/navbar-logo/image';
import './header.less'
import { BrowserRouter as Router, Route, Link, Switch, Redirect} from 'react-router-dom';

const { Header } = Layout;
const Search = Input.Search;
const Option = Select.Option;

const menu1 = (
    <Menu>
        <Menu.Item key="0">
            <a>You are all caught up! </a>

        </Menu.Item>
    </Menu>
);
const menu2 = (
    <Menu>
        <Menu.Item key="0">
            <a>No new messages</a>
        </Menu.Item>
    </Menu>
);

export default class CustomHeader extends React.Component {

    constructor(props) {
        super(props);

        console.log("PROPS ::: ", this.props);

        this.showIcon = this.props.showIcon;
        this.showBurgerMenu = this.props.showBurgerMenu;
        this.showProjects = this.props.showProjects;
        this.state = {
            collapsed: false,
            projects: [],
            openProject: "Chase Payment",
            defaultval: 'Chase Payment',
        };
        this.handleChange = this.props.handleChange;
    }
    // handleChange(value) {
    //     console.log(`selected ${value}`);

    //     const openArray = [];
    //     openArray.push(value);

    //     this.setState({ openProject: value });

    // }
    componentDidMount() {

        fetch("http://10.11.14.79/recon/product/getlist/")
            .then(res => res.json())
            .then(
                (result) => {
                    console.log("Resultt::", result)
                    this.setState({
                        projects: result
                    });
                },

                (error) => {
                    console.log("Cannot fetch product list");
                    console.log(error);
                }
            )
    }
    

    render() {

        const menu3 = (
            <Menu>
                <Menu.Item key="0" className="profileMenu">
                    <Icon type="profile" />
                    <span><a>Edit Profile</a></span>
                </Menu.Item>
                <Menu.Divider />
                <Menu.Item key="1" className="profileMenu">
                    <Icon type="read" />
                    <span><a>View Profile</a></span>
                </Menu.Item>
                {/* <Menu.Divider/>
                <Menu.Item key="2" onClick={this.props.showDrawar} className="profileMenu">
                    <Icon type="logout" />
                    <span><a>Settings</a></span>
                </Menu.Item> */}
                <Menu.Divider />
                <Menu.Item key="2" className="profileMenu">
                    <Icon type="logout" />
                    <span><a>Sign Out</a></span>
                </Menu.Item>
            </Menu>
        );


       

        return (
            <Header className='header'>

                {this.showIcon ? <div><Link to="welcome"><Image/></Link></div> : null}

                {this.showBurgerMenu ? <Icon className="burgerMenu"
                    type={this.state.collapsed ? 'menu-unfold' : 'menu-fold'}
                    onClick={this.props.collapsedClick}
                /> : null}

                {this.showProjects ? <Select placeholder="Select project" className="selectProject" defaultValue={this.state.defaultval} onChange={this.handleChange}>
                    {
                        
                        this.state.projects.map(project =>
                            <Option value={project.productName} >{project.productName}</Option>
                        )
                    }
                </Select> : null}

                <div className="headerIcons" >


                    <Dropdown overlay={menu1} trigger={['click']}>
                        <a href="#">
                            <Icon type="bell" />
                        </a>
                    </Dropdown>



                    <Dropdown overlay={menu2} trigger={['click']}>
                        <a href="#">
                            <Icon type="message" />
                        </a>
                    </Dropdown>

                    <Dropdown overlay={menu3} trigger={['click']} onClick={this.showModal}>
                        <a href="#">
                            <Icon type="user" />
                        </a>
                    </Dropdown>
                </div>
            </Header>
        );
    }

}