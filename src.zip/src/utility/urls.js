
export default {
    urlarray: 
        {           
            "GetProducts": "http://10.11.14.79/recon/product/getlist/",
            "SaveProduct": "http://10.11.14.79/recon/product/save/",
            "Login": "http://10.11.14.79/recon/login",
            "SaveReconJob": "http://10.10.18.20:8080/recon/reconJobs/TestProject",
            "GetProductDetails": "http://10.10.18.20:8080/recon/projects/TestProject1"
        }  
	
    // urlarray: 
    //     {           
    //         "GetProducts": "/recon/product/getlist/",
    //         "SaveProduct": "/recon/product/save/",
    //         "Login": "/recon/login" ,
    //         "SaveReconJob": "/recon/reconJobs/TestProject",
    //         "GetProductDetails": "/recon/projects/TestProject1" 
    //     }  
 
    // const urls = require('./../../utility/urls.js').default;

    // urls.urlarray.GetProducts
    // urls.urlarray.SaveProducts

   
}